#include<iostream>
using namespace std;

class Node {
public:
    int IDnumber;
    string name;
    double salary;
    Node* left;
    Node* right;

    Node() {
        left = NULL;
        right = NULL;
    }

    Node(int id, string n, double s) {
        IDnumber = id;
        name = n;
        salary = s;
        left = NULL;
        right = NULL;
    }
};

class BST {
public:
    Node* root;

    BST() {
        root = NULL;
    }

    void insert(Node*& temp, int id, string n, double s) {
        if (temp == NULL) {
            temp = new Node(id, n, s);
        } else if (id < temp->IDnumber) {
            insert(temp->left, id, n, s);
        } else {
            insert(temp->right, id, n, s);
        }
    }

    void inorder(Node* ptr) {
        if (ptr != NULL) {
            inorder(ptr->left);
            cout << ptr->IDnumber << " " << ptr->name << " " << ptr->salary << endl;
            inorder(ptr->right);
        }
    }

    void postorder(Node* ptr) {
        if (ptr != NULL) {
            postorder(ptr->left);
            postorder(ptr->right);
            cout << ptr->IDnumber << " " << ptr->name << " " << ptr->salary << endl;
        }
    }

    void preorder(Node* ptr) {
        if (ptr != NULL) {
            cout << ptr->IDnumber << " " << ptr->name << " " << ptr->salary << endl;
            preorder(ptr->left);
            preorder(ptr->right);
        }
    }

    bool search(Node* temp, int num) {
        if (temp == NULL)
            return false;
        else if (temp->IDnumber == num)
            return true;
        else if (num < temp->IDnumber)
            return search(temp->left, num);
        else
            return search(temp->right, num);
    }

    Node* findMin(Node* temp) {
        while (temp && temp->left != NULL) {
            temp = temp->left;
        }
        return temp;
    }

    Node* deleteNode(Node* temp, int empNum) {
        if (temp == NULL) {
            return temp;
        }

        if (empNum < temp->IDnumber) {
            temp->left = deleteNode(temp->left, empNum);
        } else if (empNum > temp->IDnumber) {
            temp->right = deleteNode(temp->right, empNum);
        } else {
            if (temp->left == NULL) {
                Node* rightChild = temp->right;
                delete temp;
                return rightChild;
            } else if (temp->right == NULL) {
                Node* leftChild = temp->left;
                delete temp;
                return leftChild;
            }

            Node* minNode = findMin(temp->right);
            temp->IDnumber = minNode->IDnumber;
            temp->name = minNode->name;
            temp->salary = minNode->salary;
            temp->right = deleteNode(temp->right, minNode->IDnumber);
        }
        return temp;
    }
};

int main() {
    BST b;

    b.insert(b.root, 1, "Amna", 20000);
	b.insert(b.root, 3, "Saira", 25000);
    b.insert(b.root, 2, "Zahra", 23000);

    cout << "Preorder traversal:" << endl;
    b.preorder(b.root);
    cout << "Inorder traversal:" << endl;
    b.inorder(b.root);
    cout << "Postorder traversal:" << endl;
    b.postorder(b.root);
    cout<<endl;

    cout << "Search for employee ID 2: " << (b.search(b.root, 2) ? "Found" : "Not Found") << endl;
    cout<<endl;

    cout << "Deleting employee with ID 3." << endl;
    b.root = b.deleteNode(b.root, 3);
    cout<<endl;
    
    cout << "Preorder traversal after deletion:" << endl;
    b.preorder(b.root);

    cout << "Inorder traversal after deletion:" << endl;
    b.inorder(b.root);
    
    cout << "Postorder traversal after deletion:" << endl;
    b.postorder(b.root);

    return 0;
}

