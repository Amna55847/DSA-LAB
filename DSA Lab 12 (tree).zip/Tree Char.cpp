#include <iostream>
using namespace std;

class node {
    public:
        char data;  // Changed from int to char to store letters
        node *left;
        node *right;
        
        node(char val) {  // Constructor now takes a char
            data = val;
            left = NULL;
            right = NULL;
        }
};

class Binarytree {
    public:
        node *root;

        Binarytree() {
            root = NULL;
        }

        void PreOrder(node *temp) {
            if (temp != NULL) {
                cout << "  " << temp->data;  // Print the character value
                PreOrder(temp->left);
                PreOrder(temp->right);
            }
        }

        void InOrder(node *temp) {
            if (temp != NULL) {
                InOrder(temp->left);
                cout << "  " << temp->data;  // Print the character value
                InOrder(temp->right);
            }
        }

        void PostOrder(node *temp) {
            if (temp != NULL) {
                PostOrder(temp->left);
                PostOrder(temp->right);
                cout << "  " << temp->data;  // Print the character value
            }
        }

        void display() {
            cout << "PreOrder: ";
            PreOrder(root);
            cout << endl;

            cout << "InOrder: ";
            InOrder(root);
            cout << endl;

            cout << "PostOrder: ";
            PostOrder(root);
            cout << endl;
        }
};

int main() {
    Binarytree tree;

    // Insert nodes with letters instead of numbers
    tree.root = new node('A');
    tree.root->left = new node('B');
    tree.root->right = new node('C');
    tree.root->left->left = new node('D');
    tree.root->right->right = new node('E');

    tree.display();  // Display the tree traversal

    return 0;
}